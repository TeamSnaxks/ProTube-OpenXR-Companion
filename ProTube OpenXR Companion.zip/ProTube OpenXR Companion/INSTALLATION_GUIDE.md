# ProTube OpenXR Companion - Installation Guide


## Disclaimer

This is an unofficial modification. Not affiliated with or endorsed by ProTubeVR or Virtual Desktop.
Use at your own risk. Always backup original files before installation. 

Improper use of the haptic filter, shot duration and latency compensation options at their extremes can create unwanted repeat cycling of the device. Please understand what each does and how it relates to your game's haptics before setting. 

---

**Version:** 1.0 (beta)  
**Last Updated:** January 2026



## Simple 3-Step Installation

No installer needed - just follow these simple steps!

---

## Prerequisites

Before installing, ensure you have:

1. **Virtual Desktop / Virtual Desktop Streamer** 
2. **ProTube VR Hardware** 

---

## Installation Steps

### Step 1: Backup & Replace Virtual Desktop DLL

1. **Navigate to Virtual Desktop Streamer folder:**
   - Open File Explorer
   - Go to: `C:\Program Files\Virtual Desktop Streamer\OpenXR\`
   
2. **Backup the original DLL:**
   - Find: `virtualdesktop-openxr.dll`
   - Right-click → Rename
   - Change name to: `virtualdesktop-openxr.dll.backup`
   - **IMPORTANT:** Keep this backup! You can restore it anytime.

3. **Install the modified DLL:**
   - Open the `DLL` folder from this package
   - Copy: `virtualdesktop-openxr.dll`
   - Paste it into: `C:\Program Files\Virtual Desktop Streamer\OpenXR\`
   - **You may need administrator privileges** - click "Yes" if prompted

### Step 2: Install ProTube OpenXR Companion

1. **Copy the Companion folder:**
   - Find the `ProTube OpenXR Companion` folder in this package
   - Copy the entire folder

2. **Paste to your Documents folder:**
   - Open File Explorer
   - Navigate to: `C:\Users\[YOUR_USERNAME]\Documents\`
   - Paste the folder here
   - Final location should be: `C:\Users\[YOUR_USERNAME]\Documents\ProTube OpenXR Companion\`

### Step 3: Create Desktop Shortcut (Optional but Recommended)

1. **Navigate to the Companion folder:**
   - Go to: `C:\Users\[YOUR_USERNAME]\Documents\ProTube OpenXR Companion\`

2. **Create shortcut:**
   - Right-click on: `ProTube OpenXR Companion.exe`
   - Select: "Send to" → "Desktop (create shortcut)"
   - Optionally rename the shortcut to just: `ProTube OpenXR Companion`

**Installation Complete!** ✅

---

## First Time Setup

### Launch the Application

1. **Open the GUI:**
   - Double-click the desktop shortcut
   - OR navigate to `Documents\ProTube OpenXR Companion\` and double-click `ProTube OpenXR Companion.exe`

2. **Select the correct Haptic Mode for the game you will play:** 
   - Trigger Mode for games with no haptic support
   - OR Haptic Filtered for games with haptic suppport (haptic support games rumble your controllers)
   - This is the only setting that cannot be changed after launching the OpenXR/VDXR runtime

3. **Start the Bridge:**
   - Click the **"Start Bridge"** button in the GUI
   - The Bridge Status indicator should turn green and the light will turn solid on your device
   - Battery level should display after a few moments (if supported by your ProTube model)

### Configure Your Settings

The default settings load on first launch, but you can customize and save using the Save As and Load options:

2. **Adjust Haptic Feedback:**
   - **Single Shot:** Kick strength, rumble, duration
   - **Burst Fire:** Kick strength, rumble, duration, burst count
   - **Full Auto:** Kick strength, rumble, duration, fire rate

3. **Additional Options:**
   - **Haptic Feedback Toggle:** Enable/disable mode switching feedback
   - **Ignore Left Hand:** Disable left controller trigger input
   - **Latency Compensation:** Adjust timing (0-200ms)

4. **All settings auto-save** to "protube_gui_config.json". This file allows live changes, leave it in place and unmodified. Save your custom Configs in the "OpenXR Companion Configs" folder

---

## Usage

### In-Game Fire Mode Controls

Use the **B Button** (upper right button on right controller):
- **Hold 1 second** = Single Shot Mode
- **Double tap** = Burst Fire Mode  
- **Triple tap** = Full Auto Mode

**Mode Confirmation:**
You'll feel low strength kicks confirming the mode:
- 1 pulse = Single Shot
- 2 pulses = Burst Fire
- 3 pulses = Full Auto

If you dont like or want this, toggle off the Haptic Feedback switch 

### Loading Custom Configs

1. Click **"Load Config"** in the GUI
2. Navigate to a config file (`.json`)
3. Select and open it
4. Settings will update immediately

### Saving Custom Configs

1. Adjust settings to your preference
2. Click **"Save Config"**
3. Choose a location and filename
4. Your custom config can be loaded later

---

## Troubleshooting

### Application Won't Start

**Issue:** Double-clicking the EXE does nothing or shows an error

**Solutions:**
- Make sure `ForceTubeVR_API_x64.dll` is in the same folder as the EXE files
- Check that ProTube hardware is connected
- Try running as Administrator: Right-click EXE → "Run as administrator"

### Bridge Won't Start

**Issue:** Clicking "Start Bridge" does nothing or shows an error

**Solutions:**
- Check that `ForceTubeVR_API_x64.dll` is present
- Make sure ProTube hardware is connected and powered on
- Close and restart the GUI application

### No Haptic Feedback

**Issue:** GUI shows bridge running, but no haptic feedback in VR

**Solutions:**
- Verify Bridge is running (green indicator in GUI)
- Check that Virtual Desktop is running and connected
- Ensure the modified DLL is installed correctly
- Try toggling "Haptic Feedback" off and back on in the GUI
- Verify your fire mode selection (Haptic or Haptic Filtered)

### Battery Shows "---%" 

**Issue:** Battery percentage not displaying

**Solution:**
- Some ProTube models don't support battery reporting
- This is normal and doesn't affect functionality

### Virtual Desktop Not Working / VR Issues

**Issue:** Virtual Desktop won't start or VR doesn't work correctly when playing games that dont use the ProTube OpenXR Companion:

**Solution - Restore Original DLL:**
1. Navigate to: `C:\Program Files\Virtual Desktop Streamer\OpenXR\`
2. Delete: `virtualdesktop-openxr.dll` (modified version)
3. Rename: `virtualdesktop-openxr.dll.backup` back to `virtualdesktop-openxr.dll`
4. Restart Virtual Desktop

### Settings Not Saving

**Issue:** Changes reset when closing the application

**Solutions:**
- Check that `protube_gui_config.json` exists in the Companion folder
- Make sure the folder isn't read-only
- Try running as Administrator

---

## Uninstallation

To completely remove ProTube OpenXR Companion:

### Step 1: Restore Original Virtual Desktop DLL

1. Navigate to: `C:\Program Files\Virtual Desktop Streamer\OpenXR\`
2. Delete: `virtualdesktop-openxr.dll` (modified version)
3. Rename: `virtualdesktop-openxr.dll.backup` to `virtualdesktop-openxr.dll`
4. Restart Virtual Desktop Streamer

### Step 2: Remove Companion Files

1. Delete folder: `C:\Users\[YOUR_USERNAME]\Documents\ProTube OpenXR Companion\`
2. Delete desktop shortcut (if created)

**Uninstallation Complete!**

---

## File Locations Reference

**Virtual Desktop DLL:**
- Location: `C:\Program Files\Virtual Desktop Streamer\OpenXR\`
- Modified file: `virtualdesktop-openxr.dll`
- Backup: `virtualdesktop-openxr.dll.backup`

**ProTube Companion:**
- Location: `C:\Users\[YOUR_USERNAME]\Documents\ProTube OpenXR Companion\`
- Main EXE: `ProTube OpenXR Companion.exe`
- Bridge EXE: `ProTube OpenXR Bridge.exe`(runs hidden - only launch from ProTube OpenXR Companion app)
- Config file: `protube_gui_config.json` (auto-created/updated)
- Driver config: `protube_config.txt` (auto-created by bridge)
- Battery file: `protube_battery.txt` (temporary, created by bridge)

---

## Advanced Configuration

### Game-Specific Profiles

The `OpenXR Companion Configs` folder contains game profiles. To use them:

1. Load the default config as a starting point
2. Adjust settings for your specific game
3. Save as a new config with the game name
4. Load this config when playing that game

### Fire Mode Recommendations

**Single Shot Mode:**
- Best for: Pistols, sniper rifles, shotguns
- Typical settings: High kick, medium rumble, short duration

**Burst Fire Mode:**
- Best for: Tactical rifles, burst weapons
- Typical settings: Medium kick, medium rumble, 3-shot burst

**Full Auto Mode:**
- Best for: Machine guns, SMGs, automatic rifles  
- Typical settings: Lower kick, higher rumble, fast fire rate

---

## Support

For additional help:
- Check the troubleshooting section above
- Review configuration files in the Companion folder
- Verify all files are in the correct locations

---

## Credits

- ProTube VR hardware by ProTubeVR
- Virtual Desktop by Guy Godin
- OpenXR modifications for ProTube integration


