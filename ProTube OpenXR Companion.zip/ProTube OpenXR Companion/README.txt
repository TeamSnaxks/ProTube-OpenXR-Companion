# ProTube OpenXR Companion v1.0

Unofficial ProTube VR haptic feedback integration for Virtual Desktop OpenXR

---

## What's This?

Adds ProTube VR gun accessory support to Virtual Desktop, enabling:
- ✅ Realistic haptic feedback kick and rumble
- ✅ 3 fire modes (Single, Burst, Full Auto)
- ✅ Customizable haptic strength and timing
- ✅ Real-time configuration without restarting

---

## Quick Install

**3 Simple Steps:**

1. **Replace Virtual Desktop DLL** (in `Program Files\Virtual Desktop Streamer\OpenXR\`)
2. **Copy Companion folder** (to your Documents folder)
3. **Run the EXE** and click "Start Bridge"

See `QUICK_START.txt` for step-by-step instructions.

---

## What's Included

📁 **DLL Folder**
- Modified Virtual Desktop OpenXR DLL with ProTube support

📁 **ProTube OpenXR Companion Folder**
- Bridge Application (EXE) - Handles haptic feedback
- Configuration folder
- ForceTube API DLL

📄 **Documentation**
- `QUICK_START.txt` - Fast 3-step guide
- `INSTALLATION_GUIDE.md` - Detailed instructions with troubleshooting

---

## Features

**Fire Modes:**
- Single Shot - One kick per trigger pull
- Burst Fire - Configurable burst count
- Full Auto - Continuous fire while trigger held

**Customization:**
- Kick strength (0-100%)
- Rumble intensity (0-100%)
- Kick duration (10-500ms)
- Fire rate for auto/burst modes
- Latency compensation (0-200ms)

**Options:**
- 3 haptic modes (Trigger, Haptic, Haptic Filtered)
- Ignore left hand toggle
- Battery monitoring
- Real-time settings changes

---

## In-Game Controls

**B Button (right controller):**
- Hold 1 second → Single Shot
- Double tap → Burst Fire
- Triple tap → Full Auto

You'll feel 1-3 haptic pulses confirming the mode.

---

## Requirements

- ✅ Windows 10 or 11
- ✅ Virtual Desktop / Virtual Desktop Streamer
- ✅ ProTube VR hardware (Only tested with Original ProVolver so far)

---

## Support

**Need help?**
- Check `INSTALLATION_GUIDE.md` for troubleshooting
- Verify all files are in correct locations
- Make sure ProTube hardware is connected

**To uninstall:**
1. Restore original Virtual Desktop DLL (rename `.backup` file)
2. Delete the Companion folder from Documents

---

## Credits

- ProTube VR hardware by ProTubeVR
- Virtual Desktop by Guy Godin  
- OpenXR integration modifications

---

## Disclaimer

This is an unofficial modification. Not affiliated with or endorsed by ProTubeVR or Virtual Desktop.
Use at your own risk. Always backup original files before installation. 

Improper use of the haptic filter, shot duration and latency compensation options at their extremes can create unwanted repeat cycling of the device. Please understand what each does and how it relates to your game's haptics before setting. 

---

**Version:** 1.0 (beta)  
**Last Updated:** January 2026
